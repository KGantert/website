All figures created by the Matlab code will be automatically saved here as a .png file!
