All figures created by the Dynare/Matlab code will be automatically saved here as a .png file!
