% Loop over different models (goods market SaM, home production, capital utilization)
for tt = 1:4
    % CALL DYNARE
    % ---------------------------------------------------------------------
    if tt == 1
        %
        load('parameters_updated.mat');
        % Call Dynare time allocation model
        eval(['dynare nk_housework.dyn -Dreplic_number=' num2str(replicnumber) ...
            ' -Dsimul_replic_number=' num2str(simreplicnumber) ' -Ddrop_number=' num2str(dropnumber) ...
	        ' -Dapprox_order=' num2str(approxorder) ' -Dirf_periods=' num2str(irfperiod) ...
	        ' -Dsim_periods=' num2str(simperiod) ' noclearall;']);
    elseif tt == 2
        %
        load('parameters_updated.mat');
        ls_target   = 1;
        parHW.alpH  = 0.33;
        par.delM1   = 0.025;
        par.kapMI   = 4;
        par.delM2   = 0.3;
        % Call Dynare time allocation model
        eval(['dynare nk_housework.dyn -Dreplic_number=' num2str(replicnumber) ...
            ' -Dsimul_replic_number=' num2str(simreplicnumber) ' -Ddrop_number=' num2str(dropnumber) ...
	        ' -Dapprox_order=' num2str(approxorder) ' -Dirf_periods=' num2str(irfperiod) ...
	        ' -Dsim_periods=' num2str(simperiod) ' noclearall;']);
        
    elseif tt == 3
        % Call Dynare time allocation model
        load('parameters_updated.mat');
        % DYNARE
        eval(['dynare nk_time.dyn -Dreplic_number=' num2str(replicnumber) ...
            ' -Dsimul_replic_number=' num2str(simreplicnumber) ' -Ddrop_number=' num2str(dropnumber) ...
	        ' -Dapprox_order=' num2str(approxorder) ' -Dirf_periods=' num2str(irfperiod) ...
	        ' -Dsim_periods=' num2str(simperiod) ' noclearall;']);
    elseif tt == 4
        % Call Dynare time allocation model + longterm SaM elements
        load('parameters_updated.mat');
        ls_target   = 1;
        parHW.alpH  = 0.33;
        par.delM1   = 0.025;
        par.kapMI   = 4;
        par.delM2   = 0.3;
        % DYNARE
        eval(['dynare nk_time.dyn -Dreplic_number=' num2str(replicnumber) ...
            ' -Dsimul_replic_number=' num2str(simreplicnumber) ' -Ddrop_number=' num2str(dropnumber) ...
	        ' -Dapprox_order=' num2str(approxorder) ' -Dirf_periods=' num2str(irfperiod) ...
	        ' -Dsim_periods=' num2str(simperiod) ' noclearall;']);
    end

    % RETRIEVE SIMULATED DATA
    % ---------------------------------------------------------------------
    for ii = 1:length(var_sim_select)
        var_ind_CAP(ii)     = find(cellstr(M_.endo_names)==var_sim_select(ii));
    end
    % Simulated data
    y_sim_CAP = transpose(oo_.endo_simul(var_ind_CAP,:));

    % CALCULATE IRFs
    % ---------------------------------------------------------------------
    for ii = 1:length(M_.exo_names)
        for hh = 1:length(var_sim_select)
            eval(['irf_CAP_' char(M_.exo_names(ii)) '.' char(var_sim_select(hh)) '(:,tt)' ... 
                    '= transpose(oo_.irfs.' char(var_sim_select(hh)) '_' char(M_.exo_names(ii)) ').*100;']);
        end
    end

    % CALCULATE SIMULATED SECOND MOMENTS
    % ---------------------------------------------------------------------
    % Detrending
    [~,y_cyc_CAP]   = one_sided_hp_filter(y_sim_CAP(dropnumber+1:end,:),1600);
    % Relative Standard Deviations
    for hh = 1:size(y_cyc_CAP,2)
        for jj = 1:size(y_cyc_CAP,2)
            relstd_CAP(hh,jj,tt)   = std(y_cyc_CAP(:,hh)) ./ std(y_cyc_CAP(:,jj));
        end
    end
    % Contemporaneous Correlations
    corr_CAP(:,:,tt)    =  corrcoef(y_cyc_CAP);

    % Clear structures from the previous loop
    clearvars M_ oo_;

end

% -------------------------------------------------------------------------
% IRFs Output Gap and Inflation - TFP (PRESENTATION!)
% Create IRF figures as specified above
if homeprod == 0
    figure('Name','IRFs to a TFP Shock (excl Home Production)')
elseif homeprod == 1
    figure('Name','IRFs to a TFP Shock (incl Home Production)')
end
% Set up tiled layout depending on number of variables
tiledlayout(3, 3);
% Loop IRF figures over all selected variables
for ii = 1:length(var_select)
        % Create next tile in the loop
        nexttile;
        % Plot all four different model IRFs in one graph
        hold on;
        yline(0,'c');
        eval(['area(irf_CAP_eA.' char(var_select(ii)) '(:,1),"LineStyle","none","FaceColor",[0.3 0.3 0.3],"FaceAlpha",0.33)']);
        eval(['area(irf_CAP_eA.' char(var_select(ii)) '(:,2),"LineStyle","none","FaceColor",[0.7 0.3 0.3],"FaceAlpha",0.33)']);%o
        eval(['plot(irf_CAP_eA.' char(var_select(ii)) '(:,3),"x-","LineWidth",1,"Color",[0, 0.4470, 0.7410])']);%*
        eval(['plot(irf_CAP_eA.' char(var_select(ii)) '(:,4),"v-","LineWidth",1,"Color",[0.8500, 0.3250, 0.0980])']);%v%,"LineStyle","none"
        hold off;
        axis tight;
        % Show variable name as ylabel in first column
        title(char(title_select(ii)));
        ylabel('%-Dev.')
        xlabel('Quarters');  
end
% Print legend with the gamma values for the different models
leg = legend("", "Benchmark","Benchmark + Capital", "Simple SaM Model", ...
                "Simple SaM Model + Capital", 'Location', 'southoutside', ...
                'orientation', 'horizontal', 'NumColumns', 4);
leg.Layout.Tile = 'South';
% Save figure
set(gcf, 'Units', 'centimeters');
set(gcf, 'Position', [0 0 width height]);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [width height]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 width height]);
fontsize(gcf, 7,"points")
exportgraphics(gcf, 'figures/fig_irf_robust_capital_tfp.png', 'Resolution',600)

% -------------------------------------------------------------------------
% IRFs Output Gap and Inflation - Monetary Policy (PRESENTATION!)
% Create IRF figures as specified above
if homeprod == 0
    figure('Name','IRFs to a Monetary Policy Shock (excl Home Production)')
elseif homeprod == 1
    figure('Name','IRFs to a Monetary Policy Shock (incl Home Production)')
end
% Set up tiled layout depending on number of variables
tiledlayout(3, 3);
% Loop IRF figures over all selected variables
for ii = 1:length(var_select)
        % Create next tile in the loop
        nexttile;
        % Plot all four different model IRFs in one graph
        hold on;
        yline(0,'c');
        eval(['area(irf_CAP_eM.' char(var_select(ii)) '(:,1),"LineStyle","none","FaceColor",[0.3 0.3 0.3],"FaceAlpha",0.33)']);
        eval(['area(irf_CAP_eM.' char(var_select(ii)) '(:,2),"LineStyle","none","FaceColor",[0.7 0.3 0.3],"FaceAlpha",0.33)']);%o
        eval(['plot(irf_CAP_eM.' char(var_select(ii)) '(:,3),"x-","LineWidth",1,"Color",[0, 0.4470, 0.7410])']);%*
        eval(['plot(irf_CAP_eM.' char(var_select(ii)) '(:,4),"v-","LineWidth",1,"Color",[0.8500, 0.3250, 0.0980])']);%,"LineStyle","none"
        hold off;
        axis tight;
        % Show variable name as ylabel in first column
        title(char(title_select(ii)));
        ylabel('%-Dev.')
        xlabel('Quarters');  
end
% Print legend with the gamma values for the different models
leg = legend("", "Benchmark","Benchmark + Capital", "Simple SaM Model", ...
                "Simple SaM Model + Capital", 'Location', 'southoutside', ...
                'orientation', 'horizontal', 'NumColumns', 4);
leg.Layout.Tile = 'South';
% Save figure
set(gcf, 'Units', 'centimeters');
set(gcf, 'Position', [0 0 width height]);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [width height]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 width height]);
fontsize(gcf, 7,"points")
exportgraphics(gcf, 'figures/fig_irf_robust_capital_policy.png', 'Resolution',600)

% -------------------------------------------------------------------------
% IRFs Output Gap and Inflation - SEARCH EFFORT
% Create IRF figures as specified above
if homeprod == 0
    figure('Name','IRFs to a Search Effort Shock (excl Home Production)')
elseif homeprod == 1
    figure('Name','IRFs to a Search Effort Shock (incl Home Production)')
end
% Set up tiled layout depending on number of variables
tiledlayout(3, 3);
% Loop IRF figures over all selected variables
for ii = 1:length(var_select)
        % Create next tile in the loop
        nexttile;
        % Plot all four different model IRFs in one graph
        hold on;
        yline(0,'c');
        eval(['area(irf_CAP_eD.' char(var_select(ii)) '(:,1),"LineStyle","none","FaceColor",[0.3 0.3 0.3],"FaceAlpha",0.33)']);
        eval(['area(irf_CAP_eD.' char(var_select(ii)) '(:,2),"LineStyle","none","FaceColor",[0.7 0.3 0.3],"FaceAlpha",0.33)']);%o
        eval(['plot(irf_CAP_eD.' char(var_select(ii)) '(:,3),"x-","LineWidth",1,"Color",[0, 0.4470, 0.7410])']);%*
        eval(['plot(irf_CAP_eD.' char(var_select(ii)) '(:,4),"v-","LineWidth",1,"Color",[0.8500, 0.3250, 0.0980])']);%,"LineStyle","none"
        hold off;
        axis tight;
        % Show variable name as ylabel in first column
        title(char(title_select(ii)));
        ylabel('%-Dev.')
        xlabel('Quarters');  
end
% Print legend with the gamma values for the different models
leg = legend("", "Benchmark","Benchmark + Capital", "Simple SaM Model", ...
                "Simple SaM Model + Capital", 'Location', 'southoutside', ...
                'orientation', 'horizontal', 'NumColumns', 4);
leg.Layout.Tile = 'South';
% Save figure
set(gcf, 'Units', 'centimeters');
set(gcf, 'Position', [0 0 width height]);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [width height]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 width height]);
fontsize(gcf, 7,"points")
exportgraphics(gcf, 'figures/fig_irf_robust_capital_search.png', 'Resolution',600)

% -------------------------------------------------------------------------
% IRFs Output Gap and Inflation - Matching Efficiency
% Create IRF figures as specified above
if homeprod == 0
    figure('Name','IRFs to a Matching Efficiency Shock (excl Home Production)')
elseif homeprod == 1
    figure('Name','IRFs to a Matching Efficiency Shock (incl Home Production)')
end
% Set up tiled layout depending on number of variables
tiledlayout(3, 3);
% Loop IRF figures over all selected variables
for ii = 1:length(var_select)
        % Create next tile in the loop
        nexttile;
        % Plot all four different model IRFs in one graph
        hold on;
        yline(0,'c');
        eval(['area(irf_CAP_eT.' char(var_select(ii)) '(:,1),"LineStyle","none","FaceColor",[0.3 0.3 0.3],"FaceAlpha",0.33)']);
        eval(['area(irf_CAP_eT.' char(var_select(ii)) '(:,2),"LineStyle","none","FaceColor",[0.7 0.3 0.3],"FaceAlpha",0.33)']);%o
        eval(['plot(irf_CAP_eT.' char(var_select(ii)) '(:,3),"x-","LineWidth",1,"Color",[0, 0.4470, 0.7410])']);%*
        eval(['plot(irf_CAP_eT.' char(var_select(ii)) '(:,4),"v-","LineWidth",1,"Color",[0.8500, 0.3250, 0.0980])']);%,"LineStyle","none"
        hold off;
        axis tight;
        % Show variable name as ylabel in first column
        title(char(title_select(ii)));
        ylabel('%-Dev.')
        xlabel('Quarters');  
end
% Print legend with the gamma values for the different models
leg = legend("", "Benchmark","Benchmark + Capital", "Simple SaM Model", ...
                "Simple SaM Model + Capital", 'Location', 'southoutside', ...
                'orientation', 'horizontal', 'NumColumns', 4);
leg.Layout.Tile = 'South';
% Save figure
set(gcf, 'Units', 'centimeters');
set(gcf, 'Position', [0 0 width height]);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [width height]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 width height]);
fontsize(gcf, 7,"points")
exportgraphics(gcf, 'figures/fig_irf_robust_capital_efficiency.png', 'Resolution',600)

% -------------------------------------------------------------------------
% IRFs Output Gap and Inflation - EIS
% Create IRF figures as specified above
if homeprod == 0
    figure('Name','IRFs to an EIS Shock (excl Home Production)')
elseif homeprod == 1
    figure('Name','IRFs to an EIS Shock (incl Home Production)')
end
% Set up tiled layout depending on number of variables
tiledlayout(3, 3);
% Loop IRF figures over all selected variables
for ii = 1:length(var_select)
        % Create next tile in the loop
        nexttile;
        % Plot all four different model IRFs in one graph
        hold on;
        yline(0,'c');
        eval(['area(irf_CAP_eP.' char(var_select(ii)) '(:,1),"LineStyle","none","FaceColor",[0.3 0.3 0.3],"FaceAlpha",0.33)']);
        eval(['area(irf_CAP_eP.' char(var_select(ii)) '(:,2),"LineStyle","none","FaceColor",[0.7 0.3 0.3],"FaceAlpha",0.33)']);%o
        eval(['plot(irf_CAP_eP.' char(var_select(ii)) '(:,3),"x-","LineWidth",1,"Color",[0, 0.4470, 0.7410])']);%*
        eval(['plot(irf_CAP_eP.' char(var_select(ii)) '(:,4),"v-","LineWidth",1,"Color",[0.8500, 0.3250, 0.0980])']);%,"LineStyle","none"
        hold off;
        axis tight;
        % Show variable name as ylabel in first column
        title(char(title_select(ii)));
        ylabel('%-Dev.')
        xlabel('Quarters');  
end
% Print legend with the gamma values for the different models
leg = legend("", "Benchmark","Benchmark + Capital", "Simple SaM Model", ...
                "Simple SaM Model + Capital", 'Location', 'southoutside', ...
                'orientation', 'horizontal', 'NumColumns', 4);
leg.Layout.Tile = 'South';
% Save figure
set(gcf, 'Units', 'centimeters');
set(gcf, 'Position', [0 0 width height]);
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [width height]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 width height]);
fontsize(gcf, 7,"points")
exportgraphics(gcf, 'figures/fig_irf_robust_capital_eis.png', 'Resolution',600)